'''
This module deals with client-side
of the application using async io
'''
import asyncio

async def client_opr():
    '''
    This method is used for client to perform operations
    '''

    reader, writer = await asyncio.open_connection('127.0.0.1',8888)
    feedback = ''
    while True:
        feedback = input('Enter command:')
        if feedback == '':
            print("Invalid cmd\n")
            continue
        if feedback.rstrip("\n").rstrip(" ").lstrip(" ") == "commands":
            cmds={"register":"register <username> <password>\n",
            "login":"login <username> <password>\n",
            "list": "list\n",
            "read_file": "for reading cmd:-> read_file <name> \nto close opened file cmd:-> read_file\n",
            "write_file": "for writing into a file cmd:-> write_file <name> <input>\nto remove contents cmd:-> write_file <name>\n",
            "change_folder":"To change folder cmd:-> change_folder <name> \nTo previous folder cmd:-> change_folder ..\n",
            "create_folder":"create_folder <name>\n"
            }
            for i in cmds:
                print(f"{i} - {cmds[i]}")
            continue

        writer.write(feedback.encode())

        data = await reader.read(1000)
        print(f'Received: {data.decode()}')
        if feedback.lower() == "quit":
            break
    print('Close the connection')
    writer.close()
try:
    asyncio.run(client_opr())
except:
    print("Error occured please verify")
