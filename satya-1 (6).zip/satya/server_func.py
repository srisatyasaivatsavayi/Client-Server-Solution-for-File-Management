""" THis module is for user side operations"""
import os
import time
import pandas

class Operations():
    '''
        This class contains all operations that can be performed by user.
    '''
    def __init__(self):
        ''' Intial variables declaretion'''
        self.identity = None
        self.logged_in = False
        self.in_users = None
        self.users_log = None
        self.direc_user = None
        self.index_count = {}
        self.cmd="quit"

    def change_folder(self,dir_name):
        '''
            This method changes to other folder from current directory
            can also go back to previous directory
        '''

        if not self.logged_in:
            return "\nlogin to continue to perform operations"
        elif dir_name in os.listdir(self.direc_user):
            self.direc_user +=f"/{dir_name}"
            return f"changed to new directory >>>{self.direc_user}<<<"
        elif dir_name == "..":
            try:
                if len(self.direc_user.split("/")) > 2:
                    temp_dir = self.direc_user.split("/")[0:-1]

                    self.direc_user = "/".join(temp_dir)
                    return f"changed to new directory >>>{self.direc_user}"
                else:
                    return f"directory can't be change. current directory:{self.direc_user}<<<"
            except:
                print("Cannot go back to previous folder")
        else:
            return f"No such folder is found!!!!, check name once"

    def register(self, registered_id, registered_password):

        '''
            This methods registers new users into server.
        '''
        try:
            if self.logged_in:
                return "\n must logout for new registration, to logout enter command:->quit"

            log_of_users = pandas.read_csv("Server_data/users.csv")
            try:
                if registered_id in log_of_users['username'].tolist():
                    return "Username already taken try again with another name"
                else:
                    entry=pandas.DataFrame(columns=['username','password'])
                    new_entry = entry
                    
                    os.mkdir(os.path.join("Root/",str(registered_id)))

                    new_entry['username'] = [registered_id]
                    new_entry['password'] = registered_password
                    log_of_users = log_of_users.append(new_entry)
                    log_of_users.to_csv("Server_data/Users.csv",index = False)

                    return "\nUser Registered"
            except OSError:
                print("Os error occured")
        except MemoryError:
            print("Memory is full")


    def create_folder(self,dir_name):

        '''
        This method is used to create folder in current directory
        '''

        if not self.logged_in:
            return "\nlogin to continue to perform operations"
        path = self.direc_user
        list_dir=os.listdir(path)
        all_files_names = list_dir
        if dir_name in all_files_names:
            return "Folder existed already"
        else:
            os.mkdir(os.path.join(path, dir_name))
            return f"File created successfully in {self.direc_user}"

    def login(self, identity, pass_word):

        '''
        This method is used for user to login.
        '''

        self.users_log = pandas.read_csv("Server_data/current_users.csv")
        self.in_users = pandas.read_csv("Server_data/users.csv")

        empty_dict = {}

        if self.logged_in:
            return f"\n User {self.identity} already logged in"

        users_in_server = []
        passcode_of_user = []

        in_server_users = self.users_log
        empty_dict = self.in_users.to_dict('split')

        i = 0
        j=0
        while i<len(empty_dict['index']):
            users_in_server.append(empty_dict['data'][i][j])
            passcode_of_user.append(empty_dict['data'][i][j+1])
            i=i+1

        if identity not in users_in_server:
            return "\nUsername Invalid"
        elif pass_word not in passcode_of_user:
            return "\nWrong password"
        elif identity in in_server_users['username'].tolist():
            return "\nUser already logged in from another address"

        def login_folder(identity,in_server_users):
            new_logged_user_entry = pandas.DataFrame(columns=['username'])
            self.identity = identity
            self.direc_user = "Root/" + identity
            new_logged_user_entry['username'] = [identity]
            in_server_users = in_server_users.append(new_logged_user_entry)
            in_server_users.to_csv('Server_data/current_users.csv',index = False)

        login_folder(identity,in_server_users)

        self.logged_in = True

        return "\n User logged in"

    def list(self):

        '''
        This method displays stats of all files in current directory
        '''
        try:
            if not self.logged_in:
                return "\nlogin to continue to perform operations"

            file_info_ls = []
            sample_list=os.listdir(self.direc_user)
            for file_id in sample_list:
                file_stat_obj = os.stat(os.path.join(self.direc_user,file_id))
                file_stat_item = list((file_id, str(file_stat_obj.st_size),
                str(time.ctime(file_stat_obj.st_ctime))))
                file_info_ls.append(file_stat_item)

            file_detials = ''
            file_detials += f"\nFiles in ->{self.direc_user} are"+"\nFile      Size       Date & Time"
            for each in file_info_ls:
                data = "      ".join(each[0:]) + "\n"
                file_detials += "\n" + data
            return file_detials
        except RuntimeError:
            print("runtime error occured")

    def write_file(self, file_id, content_for_file = None):

        '''
        This method writes into a file or erases content in a file
        '''
        for i in range(1):
            if not self.logged_in:
                return "\nlogin to continue to perform operations"
            for j in range(i+1):
                if content_for_file == None:
                    nm_file=f"{self.direc_user}/{file_id}"
                    f_open = open(nm_file,"w")
                    f_open.write("")
                    f_open.close()
                    return f"erased contents in file ->{file_id}"
                else:
                    nm_file2=f"{self.direc_user}/{file_id}"
                    f_open = open(nm_file2,"a")
                    f_open.write(content_for_file)
                    f_open.close()
                    return f"updated >>>{file_id}<<< file"


    def read_file(self, file_id = None):

        '''
        This method reads contents inidea a given file name
        '''
        def get_file_length(path):

            f_open = open(path,"r")
            file_len = len(f_open.read())
            f_open.close()
            return file_len
        if not self.logged_in:
            return "\nlogin to continue to perform operations"
        try:
            data = None
            if file_id == None:
                self.index_count.clear()
                return "Current reading files closed"

            path = f"{self.direc_user}"+"/"+f"{file_id}"

            if path not in self.index_count.keys():
                if file_id in os.listdir(self.direc_user):
                    with open(path, 'r') as read_obj:
                        one_char = read_obj.read(1)
                        if not one_char:
                            return "***File content empty***"
                    f_open = open(path,"r")
                    self.index_count[path] = 100
                    data = f_open.read(100).rstrip()
            else:
                f_open = open(path, "r")
                if os.stat(path).st_size == 0:
                    return "***File content empty***"
                if self.index_count[path] < self.get_file_length(path):
                    f_open.seek(self.index_count[path])
                data = f_open.read(100).rstrip()
                self.index_count[path] +=100
                if self.index_count[path] > self.get_file_length(path):
                    f_open.close()
                    del self.index_count[path]

            return data
        except FileNotFoundError:
            print("FileNotFoundError occured")

    def quit(self):
        '''
        This method is used to logout and close application
        '''
        if self.cmd=="quit":
            try:
                if not self.logged_in:
                    return "login to continue to perform operations"
                user_login_data = pandas.read_csv('Server_data/current_users.csv')
                temp_user_data = user_login_data.to_dict('split')
                temp_dict = {}

                for i in range(len(user_login_data)):
                    temp_dict[temp_user_data['data'][i][0]] = temp_user_data['index'][i]

                new_user_login_data = user_login_data.drop(temp_dict[self.identity])
                new_user_login_data.to_csv('Server_data/current_users.csv',index = False)
                self.logged_in = False
                self.identity = ""
                return "User logged out"
            except OSError:
                print("OSError occured")
