'''
This modules deals with server end of the
application using async io
'''
import asyncio
import signal
import os
import pandas
from server_func import Operations

#for ctrl+c to exit
signal.signal(signal.SIGINT, signal.SIG_DFL)

def reset_everything():
    '''
    This function resets everything when everytime new server is started
    '''

    cur_users_data = pandas.DataFrame(columns=['username'])
    direc=os.getcwd()
    direc_path=direc+"/Server_data/current_users.csv"
    cur_users_data.to_csv(direc_path,index=False)

async def handle_response(reader, writer):
    '''
    This functions deals in recoginze the connection
    from client;reads from client and writes back to the client
    '''
    client_addr = writer.get_extra_info('peername')
    response = f'{client_addr} is connected !!!!'
    print(response)

    obj = Operations()

    while True:
        data = await reader.read(1000)
        response = data.decode().strip()

        print(f"Received {response} from {client_addr}")
        obj.in_users = pandas.read_csv("Server_data/users.csv")
        obj.users_log = pandas.read_csv("Server_data/current_users.csv")

        response =  response.rstrip("\n").rstrip(" ").lstrip(" ")
        cmd_name = response.split(" ")[0]
        len_cmd = len(response.split(" "))
        if cmd_name == "register":
            if len_cmd == 3:
                received_text= obj.register(response.split(" ")[1], response.split(" ")[2])
            else:
                received_text= "Command With Wrong Arguments"
        elif cmd_name == "login":
            if len_cmd == 3:
                received_text= obj.login(response.split(" ")[1], response.split(" ")[2])
            else:
                received_text= "Command with Wrong Arguments"
        elif cmd_name == "list":
            received_text= obj.list()
        elif cmd_name == "create_folder":
            if len_cmd == 2:
                received_text= obj.create_folder(response.split(" ")[1])
        elif cmd_name == "change_folder":
            if len_cmd == 2:
                received_text= obj.change_folder(response.split(" ")[1])
        elif cmd_name == "write_file":
            if len_cmd >= 3:
                received_text= obj.write_file(response.split(" ")[1]," ".join(response.split(" ")[2: ]))
            elif len_cmd == 2:
                received_text= obj.write_file(response.split(" ")[1])
        elif cmd_name == "read_file":
            if len_cmd == 2:
                received_text= obj.read_file(response.split(" ")[1])
            if len_cmd == 1:
                received_text= obj.read_file()
        elif cmd_name == "quit":
            if len_cmd == 1:
                received_text= obj.quit()
        else:
            received_text= "Invalid Command, Enter right one"

        writer.write(str(received_text).encode())
        await writer.drain()
        if response == 'quit':
            break

    print("Close the connection")
    writer.close()

async def main():
    '''
    This function establish the connection
    between client and server
    '''

    reset_everything()

    server = await asyncio.start_server(
        handle_response, '127.0.0.1', 8888
    )

    server_addr = server.sockets[0].getsockname()
    print(f'Serving on {server_addr}')

    async with server:
        await server.serve_forever()

asyncio.run(main())
