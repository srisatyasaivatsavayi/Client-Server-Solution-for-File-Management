'''
This module tests for errors in main code
'''
import unittest
import pandas
from server_func import Operations

real_users = pandas.read_csv('Server_data/users.csv')
real_current_users = pandas.read_csv('Server_data/current_users.csv')

class TestApp(unittest.TestCase):
    '''
        This class containes the test cases for commands in the application
    '''

    def test_register(self):
        '''this function tests user registration'''

        obj = Operations()
        self.assertEqual(obj.register("raju","raju1234"), '\nUser Registered')


    def test_change_folder(self):
        '''This function tests changing of folder'''

        obj = Operations()
        obj.register("iamuser", "iamuser10")
        obj.login("iamuser", "iamuser10")
        file_name = "helloworld"
        obj.create_folder(file_name)
        self.assertEqual(obj.change_folder(file_name),
        f"changed to new directory >>>{obj.direc_user}<<<")

    def test_quit(self):
        '''This function tests loggingout of user'''

        obj = Operations()
        obj.register("user1", "pass")
        obj.login("user1", "pass")
        self.assertEqual(obj.quit(), "User logged out")



def test_sequence(tests):
    '''
    The function executs the provided tests cases and 
    gives back the test results
    '''
    test_load = unittest.TestLoader()
    test_suite = unittest.TestSuite()

    test_suite.addTests(test_load.loadTestsFromTestCase(tests))
    test_run = unittest.TextTestRunner(verbosity=2)
    output = test_run.run(test_suite)

    if output.skipped:
        return False

    return output.wasSuccessful()

if __name__ == "__main__":
    print('-'*50 + "\nTesting:\n")
    if test_sequence(TestApp) is not True:
        print("\n\tThe tests did not pass,")
    